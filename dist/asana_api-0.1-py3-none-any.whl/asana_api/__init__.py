# -*- coding: utf-8 -*-
"""
Created on Wed Sep 20 11:33:19 2023

@author: nfama
"""

from .get_project import get_project